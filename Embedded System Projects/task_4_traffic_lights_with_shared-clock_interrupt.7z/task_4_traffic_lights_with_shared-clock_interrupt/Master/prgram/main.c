#include <Reg52.h>
#include "main.h"

void SCI_TICK1_MASTER_Init_T2();
void TRAFFIC_LIGHTS_Init();
void LED_Flash_Init();
void SCI_TICK1_MASTER_Start();

void TRAFFIC_LIGHTS_Update(void){
	// This is the main update code
	switch (Light_state_G){
	case RED:
		Red_light = ON;
		Amber_light = OFF;
		Green_light = OFF;
		if (++Time_in_state == RED_DURATION){
			Light_state_G = RED_AMBER;
			Time_in_state = 0;
		}
		break;
	case RED_AMBER:
		Red_light = ON;
		Amber_light = ON;
		Green_light = OFF;
		if (++Time_in_state == RED_AND_AMBER_DURATION){
			Light_state_G = GREEN;
			Time_in_state = 0;
		}
		break;
	case GREEN:
		Red_light = OFF;
		Amber_light = OFF;
		Green_light = ON;
		if (++Time_in_state == GREEN_DURATION){
			Light_state_G = AMBER;
			Time_in_state = 0;
		}
		break;
	case AMBER:
		Red_light = OFF;
		Amber_light = ON;
		Green_light = OFF;
		if (++Time_in_state == AMBER_DURATION){
			Light_state_G = RED;
			Time_in_state = 0;
		}
		break;
	}
}

void SCI_TICK1_MASTER_Update_T2(void) interrupt INTERRUPT_Timer_2_Overflow{
	TF2 = 0; // Must manually clear this.
	// Send 'tick' message to the Slave
	Interrupt_output_pin = 0;
	if(++MSecond_COUNTER == 1000){		// one second passed 
		MSecond_COUNTER = 0;
		LED_pin = !LED_pin;
		TRAFFIC_LIGHTS_Update();
	}
	// Prepare for next tick
	Interrupt_output_pin = 1;	
}

int main(){
	// Set up the scheduler
	SCI_TICK1_MASTER_Init_T2();
	// Prepare for the traffic light task
	TRAFFIC_LIGHTS_Init();
	// Prepare for the flash LED task (demo only)
	LED_Flash_Init();
	// Start the scheduler
	SCI_TICK1_MASTER_Start();
	while(1){
		//SCH_Dispatch_Tasks();
	}
	return 0;
}

void SCI_TICK1_MASTER_Init_T2(){
	// Crystal is assumed to be 12 MHz
	// The Timer 2 resolution is 0.000001 seconds (1 �s)
	// The required Timer 2 overflow is 0.001 seconds (1 ms)
	// - this takes 1000 timer ticks
	// Reload value is 65536 - 1000 = 64536 (dec) = 0xFC18
	T2CON = 0x04; // load Timer 2 control register
	TH2 = 0xFC; // load Timer 2 high byte
	RCAP2H = 0xFC; // load Timer 2 reload capture reg, high byte
	TL2 = 0x18; // load Timer 2 low byte
	RCAP2L = 0x18; // load Timer 2 reload capture reg, low byte
	ET2 = 1; // Timer 2 interrupt is enabled
	TR2 = 1; // Start Timer 2
}

void TRAFFIC_LIGHTS_Init(){
	Time_in_state = 0;
	Light_state_G = RED;
}

void LED_Flash_Init(){
	LED_pin = OFF;
}

void SCI_TICK1_MASTER_Start(void){
	// Delay here to cause the Slave to time out and reset
	// Adjust this delay to match the timeout periods on the Slaves
	// Now send first tick to start the Slave
	// (starts on falling edge)
	unsigned int Delay_Counter;
	Interrupt_output_pin = 1;
	for(Delay_Counter = 0; Delay_Counter < 500; Delay_Counter++);   // Hardware_Delay_T0(500);
	Interrupt_output_pin = 0;
	for(Delay_Counter = 0; Delay_Counter < 500; Delay_Counter++);
	// Start the scheduler
	MSecond_COUNTER = 0;
	EA = 1;
}