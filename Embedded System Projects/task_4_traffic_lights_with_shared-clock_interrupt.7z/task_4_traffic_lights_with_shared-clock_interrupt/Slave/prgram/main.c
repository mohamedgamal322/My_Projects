#include <Reg52.h>
#include "main.h"

void SCI_TICK1_SLAVE_Init();
void TRAFFIC_LIGHTS_Init();
void LED_Flash_Init();
void SCI_TICK1_SLAVE_Start();

void TRAFFIC_LIGHTS_Update(void){
	// This is the main update code
	switch (Light_state_G){
	case RED:
		Red_light = ON;
		Amber_light = OFF;
		Green_light = OFF;
		if (++Time_in_state == RED_DURATION){
			Light_state_G = RED_AMBER;
			Time_in_state = 0;
		}
		break;
	case RED_AMBER:
		Red_light = ON;
		Amber_light = ON;
		Green_light = OFF;
		if (++Time_in_state == RED_AND_AMBER_DURATION){
			Light_state_G = GREEN;
			Time_in_state = 0;
		}
		break;
	case GREEN:
		Red_light = OFF;
		Amber_light = OFF;
		Green_light = ON;
		if (++Time_in_state == GREEN_DURATION){
			Light_state_G = AMBER;
			Time_in_state = 0;
		}
		break;
	case AMBER:
		Red_light = OFF;
		Amber_light = ON;
		Green_light = OFF;
		if (++Time_in_state == AMBER_DURATION){
			Light_state_G = RED;
			Time_in_state = 0;
		}
		break;
	}
}

void SCI_TICK1_SLAVE_Update(void) interrupt INTERRUPT_EXTERNAL_0{
	if(++MSecond_COUNTER == 1000){		// one second passed 
		MSecond_COUNTER = 0;
		LED_pin = !LED_pin;
		TRAFFIC_LIGHTS_Update();
	}	
}

int main(){
	// Set up the scheduler
	SCI_TICK1_SLAVE_Init();
	// Set up the flash LED task (demo purposes)
	LED_Flash_Init();
	// Prepare for the traffic light task
	TRAFFIC_LIGHTS_Init();
	// Start the scheduler
	SCI_TICK1_SLAVE_Start();
	while(1){
		//SCH_Dispatch_Tasks();
	}
	return 0;
}

void SCI_TICK1_SLAVE_Init(){
	// The Slave is driven by an interrupt input
	// The interrupt is enabled
	EA = 1;
	IT0 = 1; // falling edge triggered
}

void TRAFFIC_LIGHTS_Init(){
	Time_in_state = 0;
	Light_state_G = GREEN;
}

void LED_Flash_Init(){
	LED_pin = OFF;
}

void SCI_TICK1_SLAVE_Start(void){
	// - Slave will keep returning here if Master does not start
	// Wait here - indefinitely - for the first tick
	while (IE0 == 0);
	// Clear the flag
	IE0 = 0;
	// Start the scheduler
	MSecond_COUNTER = 0;
	EX0 = 1;
}