#ifndef MAIN_H_
#define MAIN_H_

// ------ TLights ----------------------------------------------
sbit Red_light = (P2^0);
sbit Amber_light = (P2^1);
sbit Green_light = (P2^2);
// ------ LED_Flas -----------------------------------------------
// For flashing LED
sbit LED_pin = P2^7;

#define INTERRUPT_EXTERNAL_0 0

#define ON 0
#define OFF 1

static unsigned char Time_in_state;
static unsigned int MSecond_COUNTER;
#define RED_DURATION (10)
#define RED_AND_AMBER_DURATION (5)
#define GREEN_DURATION RED_DURATION
#define AMBER_DURATION RED_AND_AMBER_DURATION

typedef enum{GREEN, AMBER, RED, RED_AMBER} traffic_state;
traffic_state Light_state_G; 

#endif //MAIN_H_