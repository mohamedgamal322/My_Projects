#include "LIB/STD_TYPES.h"
#include "LIB/BIT_MATH.h"
#include "MCAL/DIO/DIO_interface.h"
#include "MCAL/TIM2/TIM2_interface.h"
#include "LIB/RTOS/RTO_interface.h"

void Toggle_LED1(void);
void Toggle_LED2(void);
void Toggle_LED3(void);

int main(){
	/* Initialize Schedular */
	RTO_voidInit();
	/* Add tasks */
	RTO_u8CreateTask(0, 0, 1000, &Toggle_LED1);
	RTO_u8CreateTask(1, 0, 2000, &Toggle_LED2);
	RTO_u8CreateTask(2, 0, 3000, &Toggle_LED3);
	/* Start Schedular */
	RTO_voidStart();
	while(1);
	return 0;
}

void Toggle_LED1(void){
	DIO_TogglePinValue(DIO_P2, DIO_PIN0);
}

void Toggle_LED2(void){
	DIO_TogglePinValue(DIO_P2, DIO_PIN1);
}

void Toggle_LED3(void){
	DIO_TogglePinValue(DIO_P2, DIO_PIN2);
}