/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< DEL_interface.h   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Auther: Ma7moud Mo7ammed Farouq.
Layer : MCAL.
SWC   : DELAY.
*/

#ifndef DEL_interface_H_
#define DEL_interface_H_

void delay_ms(u32 msec);

#endif // DEL_interface_H_

