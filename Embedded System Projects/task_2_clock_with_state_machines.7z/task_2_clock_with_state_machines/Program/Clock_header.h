#ifndef CLOCK_HEADER_
#define CLOCK_HEADER_

typedef enum{
	stop,
	work,
	setting
} State;

#define HOU1 0
#define HOU0 1
#define MIN1 2		
#define MIN0 3
#define SEC1 4
#define SEC0 5

#define CLOCK_COUNTING 1
#define CLOCK_STOP 0

void En_Dis(u8 index);
void Set_Clock();


#endif // CLOCK_HEADER_