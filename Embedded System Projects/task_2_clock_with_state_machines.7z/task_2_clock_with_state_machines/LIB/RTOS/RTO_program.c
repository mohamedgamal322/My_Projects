#include "LIB/STD_TYPES.h"
#include "LIB/BIT_MATH.h"
#include "MCAL/TIM2/TIM2_interface.h"

#include "LIB/RTOS/RTO_interface.h"

/*array of TCBs*/

RTO_TCB RTO_AstrTasks[RTO_u8_MAX_NUMBER_TASKS];

void RTO_voidInit(void){
    // Initialize Timer2
    M_Timer2_void_Init();
    // set tick_time to 1 ms
    M_Timer2_void_setTime(1);
	/* SET call Back Function */
	M_Timer2_void_setCallBack(&RTO_voidScheduler);
	/* Enable interrupt */
	M_Timer2_void_EnableInt();
}


RTO_ErrorState RTO_u8CreateTask(u8 priority, u16 FirstDelay, u16 periodicity, void(*ptrFunction)(void)){
	RTO_ErrorState local_enumState = NOK;
	if ((priority < RTO_u8_MAX_NUMBER_TASKS) && (ptrFunction != NULL)){
		RTO_AstrTasks[priority].TaskFirstDelay = FirstDelay;
		RTO_AstrTasks[priority].TaskPeriodicity = periodicity;
		RTO_AstrTasks[priority].TaskPriority = priority;
		RTO_AstrTasks[priority].ptrTaskFunction = ptrFunction;
		local_enumState = OK;
	}
	return local_enumState;
}

static void RTO_voidScheduler(void){
	u8 counter;
	for(counter = 0; counter < RTO_u8_MAX_NUMBER_TASKS; counter++){
		if(RTO_AstrTasks[counter].TaskFirstDelay == 0){
            /*Call Task*/
			RTO_AstrTasks[counter].ptrTaskFunction();
			/*Update for the firstDelay value by periodicity*/
			RTO_AstrTasks[counter].TaskFirstDelay = RTO_AstrTasks[counter].TaskPeriodicity - 1;

		}else{
			RTO_AstrTasks[counter].TaskFirstDelay--;
		}
	}
}

void RTO_voidStart(void){
    M_Timer2_void_TimerStart();
}
