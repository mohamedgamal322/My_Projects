/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<    TIM2_config.h  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 * Author : Ma7moud Mo7ammed Farouq.
 * Layer  : MCAL.
 * SWC    : TIMER.
 */
#ifndef TIM2_config_H_
#define TIM2_config_H_

/*
    Set frequency value in MHz  ex: for 12 MHz type 12
*/

#define Crystal_Oscillator_Frequency 11.0592

#endif // TIM_config_H_
