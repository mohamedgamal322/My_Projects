/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<    TIM_interface.h  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 * Author : Ma7moud Mo7ammed Farouq.
 * Layer  : MCAL.
 * SWC    : TIMER.
 */

#ifndef TIM2_interface_H_
#define TIM2_interface_H_


void M_Timer2_void_Init(void);
void M_Timer2_void_TimerStart(void);
void M_Timer2_void_TimerStop(void);
void M_Timer2_void_EnableInt(void);
void M_Timer2_void_DisableInt(void);
void M_Timer2_void_setCallBack(void(*ptrCallBack)(void));
void M_Timer2_void_setTime(u16 Delay);


#endif // TIM2_interface_H_
