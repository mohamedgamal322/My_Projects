/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<    TIM_program.c  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 * Author : Ma7moud Mo7ammed Farouq.
 * Layer  : MCAL.
 * SWC    : TIMER.
 */

#include "LIB/BIT_MATH.h"
#include "LIB/STD_TYPES.h"

#include "MCAL/TIM2/TIM2_private.h"
#include "MCAL/TIM2/TIM2_config.h"
#include "MCAL/TIM2/TIM2_interface.h"

void(*Timer2_ptrCallBack)(void) = NULL;

void M_Timer2_void_Init(void){
    T2CON = 0x00;
}

void M_Timer2_void_TimerStart(void){
    SET_BIT(T2CON, TR2);
}

void M_Timer2_void_TimerStop(void){
    CLR_BIT(T2CON, TR2);
}

void M_Timer2_void_EnableInt(void){
	SET_BIT(IE, EA);
    SET_BIT(IE, ET2);
}

void M_Timer2_void_DisableInt(void){
    CLR_BIT(IE, ET2);
}

void M_Timer2_void_setCallBack(void(*ptrCallBack)(void)){
    Timer2_ptrCallBack = ptrCallBack;
}

void M_Timer2_void_setTime(u16 Delay){
	u16 NumOfTicks = (Delay * Crystal_Oscillator_Frequency * 1000) / 12;
    u16 StartTickNum = 65536 - NumOfTicks;
    TL2 = StartTickNum;
    RCAP2L = TL2;
    TH2 = StartTickNum >> 8;
    RCAP2H = TH2;
}

void ISR(void)interrupt INTERRUPT_Timer_2_Overflow{
    CLR_BIT(T2CON, TF2);
    if(Timer2_ptrCallBack != NULL)Timer2_ptrCallBack();
}
