/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<    TIM2_private.h  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 * Author : Ma7moud Mo7ammed Farouq.
 * Layer  : MCAL.
 * SWC    : TIMER.
 */
#ifndef TIM2_private_H_
#define TIM2_private_H_

sfr IE    = 0xA8;

#define INTERRUPT_Timer_2_Overflow 5

/*  8052 Extensions  */
sfr T2CON  = 0xC8;
sfr RCAP2L = 0xCA;
sfr RCAP2H = 0xCB;
sfr TL2    = 0xCC;
sfr TH2    = 0xCD;

/*  IE  */
#define EA  7
#define ET2 5 //8052 only
#define ES  4
#define ET1 3
#define EX1 2
#define ET0 1
#define EX0 0

/*  T2CON  */
#define TF2    7
#define EXF2   6
#define RCLK   5
#define TCLK   4
#define EXEN2  3
#define TR2    2
#define C_T2   1
#define CP_RL2 0

#endif // TIM2_private_H_
