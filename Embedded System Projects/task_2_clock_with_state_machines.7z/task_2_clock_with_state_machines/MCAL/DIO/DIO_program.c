#include "LIB/STD_TYPES.h"
#include "LIB/BIT_MATH.h"
#include "MCAL/DIO/DIO_interface.h"
#include "MCAL/DIO/DIO_private.h"

void DIO_SetPinDirection(u8 port, u8 pin, bit direction){
	if(direction == DIO_PIN_INPUT){
		switch(port){
			case DIO_P0: SET_BIT(P0, pin);break;
			case DIO_P1: SET_BIT(P1, pin);break;
			case DIO_P2: SET_BIT(P2, pin);break;
			case DIO_P3: SET_BIT(P3, pin);break;
		}
	}else if(direction == DIO_PIN_OUTPUT){
		switch(port){
			case DIO_P0: CLR_BIT(P0, pin);break;
			case DIO_P1: CLR_BIT(P1, pin);break;
			case DIO_P2: CLR_BIT(P2, pin);break;
			case DIO_P3: CLR_BIT(P3, pin);break;
		}
	}
}
void DIO_SetPinValue(u8 port, u8 pin, bit value){
	if(value == DIO_PIN_HIGH){
		switch(port){
			case DIO_P0: SET_BIT(P0, pin);break;
			case DIO_P1: SET_BIT(P1, pin);break;
			case DIO_P2: SET_BIT(P2, pin);break;
			case DIO_P3: SET_BIT(P3, pin);break;
		}
	}else if(value == DIO_PIN_LOW){
		switch(port){
			case DIO_P0: CLR_BIT(P0, pin);break;
			case DIO_P1: CLR_BIT(P1, pin);break;
			case DIO_P2: CLR_BIT(P2, pin);break;
			case DIO_P3: CLR_BIT(P3, pin);break;
		}
	}
}
void DIO_TogglePinValue(u8 port, u8 pin){
	switch(port){
		case DIO_P0: TOG_BIT(P0, pin);break;
		case DIO_P1: TOG_BIT(P1, pin);break;
		case DIO_P2: TOG_BIT(P2, pin);break;
		case DIO_P3: TOG_BIT(P3, pin);break;
	}
}
bit DIO_GetPinValue(u8 port, u8 pin){
	switch(port){
		case DIO_P0: return GET_BIT(P0, pin);break;
		case DIO_P1: return GET_BIT(P1, pin);break;
		case DIO_P2: return GET_BIT(P2, pin);break;
		case DIO_P3: return GET_BIT(P3, pin);break;
	}
}

void DIO_SetPortDirection(u8 port, u8 direction){
	switch(port){
		case DIO_P0: P0 = direction;break;
		case DIO_P1: P1 = direction;break;
		case DIO_P2: P2 = direction;break;
		case DIO_P3: P3 = direction;break;
	}
}
void DIO_SetPortValue(u8 port, u8 value){
	switch(port){
		case DIO_P0: P0 = value;break;
		case DIO_P1: P1 = value;break;
		case DIO_P2: P2 = value;break;
		case DIO_P3: P3 = value;break;
	}
}
void DIO_TogglePortValue(u8 port){
	switch(port){
	case DIO_P0: P0 = ~P0;break;
    case DIO_P1: P1 = ~P1;break;
    case DIO_P2: P2 = ~P2;break;
    case DIO_P3: P3 = ~P3;break;
	}
	return;
}
u8 DIO_GetPortValue(u8 port){
	u8 Val;
    switch(port){
        case DIO_P0: Val = P0;break;
        case DIO_P1: Val = P1;break;
        case DIO_P2: Val = P2;break;
        case DIO_P3: Val = P3;break;
     }
     return Val;
}
