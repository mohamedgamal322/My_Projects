/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< BUT_private.h   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Auther: Ma7moud Mo7ammed Farouq.
Layer : HAL.
SWC   : BUTTON.
*/

#ifndef BUT_private_H_
#define BUT_private_H_

#endif // BUT_private_H_
