#ifndef _RTO_CONFIG_H
#define _RTO_CONFIG_H

/* choose the maximum number of tasks */
#define RTO_u8_MAX_NUMBER_TASKS 3

#endif // _RTO_CONFIG_H
