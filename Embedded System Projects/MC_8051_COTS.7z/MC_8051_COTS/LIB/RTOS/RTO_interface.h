#ifndef _RTO_INTERFACE_H
#define _RTO_INTERFACE_H

typedef enum{
    OK,
    NOK
}RTO_ErrorState;

void RTO_voidInit(void);
RTO_ErrorState RTO_u8CreateTask(u8 priority, u16 FirstDelay, u16 periodicity, void(*ptrFunction)(void));
void RTO_voidStart(void);

#endif // _RTO_INTERFACE_H
