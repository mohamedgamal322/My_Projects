#ifndef  _RTO_PRIVATE_H
#define  _RTO_PRIVATE_H

typedef struct{
	u8 TaskPriority;
	u16 TaskFirstDelay;
	u16 TaskPeriodicity;
	void(*ptrTaskFunction)(void);
}RTO_TCB;

static void RTO_voidScheduler(void);

#endif // _RTO_PRIVATE_H
