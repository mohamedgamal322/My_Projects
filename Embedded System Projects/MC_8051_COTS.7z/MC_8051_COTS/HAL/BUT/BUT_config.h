/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< BUT_config.h   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Auther: Ma7moud Mo7ammed Farouq.
Layer : HAL.
SWC   : BUTTON.
*/

#ifndef BUT_config_H_
#define BUT_config_H_

#endif // BUT_config_H_
