/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<    SSD_config.h  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 * Author : Ma7moud Mo7ammed Farouq.
 * Layer  : HAL.
 * SWC    : 7_Segment.
 */

 #ifndef SSD_config_H_
 #define SSD_config_H_

 #endif // SSD_config_H_
