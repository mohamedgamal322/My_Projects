/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<    SSD_private.h  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 * Author : Ma7moud Mo7ammed Farouq.
 * Layer  : HAL.
 * SWC    : 7_Segment.
 */

 #ifndef SSD_private_H_
 #define SSD_private_H_

 #endif // SSD_private_H_
