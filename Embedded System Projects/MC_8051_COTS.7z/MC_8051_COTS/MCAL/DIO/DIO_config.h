/*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<    DIO_config.h  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
 * Author : Ma7moud Mo7ammed Farouq.
 * Layer  : MCAL.
 * SWC    : DIO.
 */

 #ifndef DIO_config_H_
 #define DIO_config_H_

 #endif // DIO_config_H_
