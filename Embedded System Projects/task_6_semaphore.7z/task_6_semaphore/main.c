#include <FreeRTOS.h>
#include <task.h>
#include <stdio.h>
#include "pico/stdlib.h"
#include "semphr.h"

#define SWITCH_PIN 15
#define LED_PIN 14

SemaphoreHandle_t switchSemaphore;

void switchTask() {
    gpio_init(SWITCH_PIN);
    gpio_set_dir(SWITCH_PIN, GPIO_IN);
    gpio_pull_up(SWITCH_PIN);
    while (1) {
        while (gpio_get(SWITCH_PIN) == 0) {
            xSemaphoreGive(switchSemaphore);
            vTaskDelay(200);  
        }
    }
}

void ledTask() {
    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);
    gpio_put(LED_PIN,0);
    while (1) {
        if (xSemaphoreTake(switchSemaphore, portMAX_DELAY)) {
            gpio_put(LED_PIN, !gpio_get(LED_PIN));
        }
        //vTaskDelay(2000);
    }
}

int main() {
    stdio_init_all();

    switchSemaphore = xSemaphoreCreateBinary();
    xTaskCreate(switchTask, "SwitchTask", 100, NULL, 1, NULL);
    xTaskCreate(ledTask, "LedTask", 100, NULL, 1, NULL);

    vTaskStartScheduler();

    while (1) {
        // This point should never be reached
    }

    return 0;
}