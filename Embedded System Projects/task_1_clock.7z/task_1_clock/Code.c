#include <Reg52.h>
#define Seg_Data P2
#define Seg_digit P3

// 7-seg digits index
#define sec_digit_0 5
#define sec_digit_1 4
#define min_digit_0 3
#define min_digit_1 2
#define	hou_digit_0 1
#define	hou_digit_1 0

// 7-seg digits counters    
char Ho_1 = 0, Ho_0 = 0, Min_1 = 0,	Min_0 = 0, Sec_1 = 0, Sec_0 = 0;
// 7-seg truth tables
char Data[10] = {0x03, 0x9F, 0x25, 0x0D, 0x99, 0x49, 0x41, 0x1F, 0x01, 0x09};
char Digits[6] = {0x20, 0x10, 0x08, 0x04, 0x02, 0x01};

// Buttons pins
sbit start_Button = P1^0;
sbit set_Button = P1^1;
sbit next_Button = P1^2;
sbit inc_Button = P1^3;

// Flags
bit Start = 0;


void delay(int msec){
	int i,j;
	for(i=0; i<msec; i++){
		for(j=0; j<113;j++){}
	}
}

void set_clock(){
	char index = 0;
	while(!Start){
		switch(index){
			case 0:
				Seg_digit = Digits[hou_digit_1];
				Seg_Data = Data[Ho_1];
				break;
			case 1:
				Seg_digit = Digits[hou_digit_0];
				Seg_Data = Data[Ho_0];
				break;
			case 2:
				Seg_digit = Digits[min_digit_1];
				Seg_Data = Data[Min_1];
				break;
			case 3:
				Seg_digit = Digits[min_digit_0];
				Seg_Data = Data[Min_0];
				break;
			case 4:
				Seg_digit = Digits[sec_digit_1];
				Seg_Data = Data[Sec_1];
				break;
			default :
				Seg_digit = Digits[sec_digit_0];
				Seg_Data = Data[Sec_0];
				//delay(5);
		}
		if(!start_Button){
			delay(20);
			if(!start_Button){
				Start = 1;
				while(!start_Button);
				return;
			}
		}
		if(!next_Button){
			delay(20);
			if(!next_Button){
				index = (index + 1)%6;
				while(!next_Button);
			}
		}
		if(!inc_Button){
			delay(20);
			if(!inc_Button){
				switch(index){
					case 0:
						if(Ho_0 > 3)Ho_1 = (Ho_1 + 1)%2;
						else Ho_1 = (Ho_1 + 1)%3;
						break;
					case 1:
						if(Ho_1 == 2)Ho_0 = (Ho_0 + 1)%4;
						else Ho_0 = (Ho_0 + 1)%10;
						break;
					case 2:
						Min_1 = (Min_1 + 1)%6;
						break;
					case 3:
						Min_0 = (Min_0 + 1)%10;
						break;
					case 4:
						Sec_1 = (Sec_1 + 1)%6;
						break;
					default :
						Sec_0 = (Sec_0 + 1)%10;
				}
				while(!inc_Button);
			}
		}
	}	
}

int main(){
	char i;
	// Init. input pins
	start_Button = 1;
	set_Button = 1;
	next_Button = 1;
	inc_Button = 1;
	
	// Main Loop
	while(1){
		// Check if start_Button is pressed
		if(!start_Button){
			delay(20);
			if(!start_Button){
				Start = 1;
				while(!start_Button);
			}
		}

		if(Start){
			for(i=0; i<33; i++){
				Seg_digit = Digits[sec_digit_0];
				Seg_Data = Data[Sec_0];
				delay(5);
		
				Seg_digit = Digits[sec_digit_1];
				Seg_Data = Data[Sec_1];
				delay(5);
				
				Seg_digit = Digits[min_digit_0];
				Seg_Data = Data[Min_0];
				delay(5);
				
				Seg_digit = Digits[min_digit_1];
				Seg_Data = Data[Min_1];
				delay(5);
				
				Seg_digit = Digits[hou_digit_0];
				Seg_Data = Data[Ho_0];
				delay(5);
				
				Seg_digit = Digits[hou_digit_1];
				Seg_Data = Data[Ho_1];
				delay(5);
	
				//Check if set_Button is pressed
				if(!set_Button){
					delay(20);
					if(!set_Button){
						Start = 0;
						while(!set_Button);
						set_clock();
					}
				}
			}

			Sec_0 = (Sec_0 + 1)%10;
			if(Sec_0 == 0)Sec_1 = (Sec_1 + 1)%6;
			if((Sec_1 == 0)&&(Sec_0 == 0))Min_0 = (Min_0 + 1)%10;
			if((Min_0 == 0)&&(Sec_1 == 0)&&(Sec_0 == 0))Min_1 = (Min_1 + 1)%6;
			if((Min_1 == 0)&&(Min_0 == 0)&&(Sec_1 == 0)&&(Sec_0 == 0)){
				if((Ho_1 == 2)&&(Ho_0 == 3))Ho_0 = 0;
				else Ho_0 = (Ho_0 + 1)%10;
			}
			if((Ho_0 == 0)&&(Min_1 == 0)&&(Min_0 == 0)&&(Sec_1 == 0)&&(Sec_0 == 0))Ho_1 = (Ho_1 + 1)%3;
		}	
	}		  
	return 0;
}